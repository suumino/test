
def choice():

    import random
    a = []

    for i in range(1, 46):
        a.append(i)

    b = []

    for i in range(0, 10):
        b = list(b)
        number = random.randint(1, 46)
        b.append(number)
        b = set(b)
        if len(b) == 6:
            break
    b = list(b)
    c = sorted(b)
    d = ''
    for i in range(6):
        d += str(c[i])
        d += '\t'

    return d

choice()
