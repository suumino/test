from flask import Flask, render_template
from number import choice

app = Flask(__name__)

@app.route('/')
@app.route('/entry')
def entry_page() -> 'html':
    return render_template('entry.html',
                           the_title='로또 번호를 추천해드립니다!')

@app.route('/search', methods=['POST'])
def do_search() -> 'html':
    title = '이 번호로 로또를 구매하세요'
    results = str(choice())
    return render_template('results.html',
                           the_title=title,
                           the_results=results)

if __name__ == '__main__':
    app.run(debug=True)
